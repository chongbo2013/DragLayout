package service.bind.test.draglayout;

/**
 * Created by ferris on 2016/7/28.
 */
public interface IDragView {
    public void move(int x, int y);
}
