
package service.bind.test.draglayout;


import android.view.View;

public interface DragSource {

    void onDropCompleted(View targetView);
}
